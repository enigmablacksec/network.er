#!/usr/bin/env python


import pygtk
pygtk.require('2.0')
import gtk

main_window = None
filename = None
page_setup = None
settings = None
file_changed = False

class database_connect(gtk.Dialog):
    def __init__(self, parent=None):
        gtk.Dialog.__init__(self, "Database Connection", parent,
            0,
            (gtk.STOCK_CLOSE,  gtk.RESPONSE_CLOSE, gtk.STOCK_HELP, gtk.RESPONSE_HELP, "_Connect", gtk.RESPONSE_OK))
        try:
            self.set_screen(parent.get_screen())
        except AttributeError:
            self.connect('destroy', lambda *w: gtk.main_quit())
        self.connect('response', lambda d, r: d.destroy())
        self.set_default_size(500, 50)
        self.set_resizable(False)        

        vbox = gtk.VBox(False, 5)
        self.vbox.pack_start(vbox, True, True, 0)
        vbox.set_border_width(5)

        self.size_group = gtk.SizeGroup(gtk.SIZE_GROUP_HORIZONTAL)

        # Create one frame holding color options
        frame = gtk.Frame("Database")
        vbox.pack_start(frame, True, True, 0)

        table = gtk.Table(2, 2, False)
        table.set_border_width(5)
        table.set_row_spacings(5)
        table.set_col_spacings(10)
        frame.add(table)

        db_options = ("MySQL Database", "MariaDB", "MsSQL Database", "PostgreSQL")
        self.__add_row(table, 0, "_Choose database type", db_options)

        # And another frame holding line style options
        label = gtk.Label("\nBrowse for database file directory or type in input box")
        vbox.pack_start(label, False, False, 0)

        table = gtk.Table(2, 2, False)
        table.set_border_width(5)
        table.set_row_spacings(4)
        table.set_col_spacings(4)

        
        # Create our entry
        label = gtk.Label(" ")
        label.set_use_underline(True)
        table.attach(label, 0, 1, 0, 1)       
        entry = gtk.Entry()
        hbox = gtk.HBox(False, 5)
        vbox.pack_start(hbox, False, False, 0)
        vbox2 = gtk.VBox()
        vbox.pack_start(entry, False, False, 0)
        label.set_mnemonic_widget(entry)        

        hbox = gtk.HBox(False, 8)
        vbox.pack_start(hbox, False, False, 0)
        vbox2 = gtk.VBox()
        
        button = gtk.Button("_Browse Files")
        button.connect('clicked', self.do_open)
        hbox.pack_start(button)

        button = gtk.Button("_Paste Directory")
        button.connect('clicked', self.do_open)
        hbox.pack_start(button)
        # And another frame holding line style options
        label2 = gtk.Label("\nDatabase Credentials (Username and Password)          ")

        vbox.pack_start(label2, False, False, 0)

        table = gtk.Table(2, 2, False)
        table.set_border_width(5)
        table.set_row_spacings(5)
        table.set_col_spacings(10)

        user_options = gtk.Entry()
        vbox.pack_start(user_options, False, False, 0)
        end_options = gtk.Entry()
        vbox.pack_start(end_options, False, False, 0)
      

        # And a check button to turn grouping on and off

        check_button = gtk.CheckButton("_Enable logging")
        vbox.pack_start(check_button, False, False, 0)
        check_button.set_active(True)
        check_button.connect('toggled', self.on_toggle_grouping)

        self.show_all()

    def __create_option_menu(self, options):

        option_menu = gtk.combo_box_new_text()
        for opt in options:
            option_menu.append_text(opt)

        option_menu.set_active(0)
        return option_menu

    def __add_row(self, table, row, label_text, options):
        label = gtk.Label(label_text)
        label.set_use_underline(True)
        label.set_alignment(0, 1)
        table.attach(label, 0, 1, row, row + 1, gtk.EXPAND | gtk.FILL, 0, 0, 0)

        option_menu = self.__create_option_menu(options)
        label.set_mnemonic_widget(option_menu)
        self.size_group.add_widget(option_menu)
        table.attach(option_menu, 1, 2, row, row + 1, 0, 0, 0, 0)

    def on_toggle_grouping(self, check_button):

        # gtk.SIZE_GROUP_NONE is not generally useful, but is useful
        # here to show the effect of gtk.SIZE_GROUP_HORIZONTAL by
        # contrast.
        if check_button.get_active():
            self.size_group.set_mode(gtk.SIZE_GROUP_HORIZONTAL)
        else:
            self.size_group.set_mode(gtk.SIZE_GROUP_NONE)

    def load_file(open_filename):
        error_dialog = None
        try:
            contents = file(open_filename).read()
        except IOError, ex:
            error_dialog = gtk.MessageDialog(main_window,
                                             gtk.DIALOG_DESTROY_WITH_PARENT,
                                             gtk.MESSAGE_ERROR,
                                             gtk.BUTTONS_CLOSE,
                                             "Error loading file %s:\n%s" %
                                             (open_filename,
                                              str(ex)))
        else:
            try:
                contents = contents.decode("utf-8")
            except UnicodeDecodeError:
                error_dialog = gtk.MessageDialog(main_window,
                                                 gtk.DIALOG_DESTROY_WITH_PARENT,
                                                 gtk.MESSAGE_ERROR,
                                                 gtk.BUTTONS_CLOSE,
                                                 "Error loading file %s:\n%s" %
                                                 (open_filename,
                                                  "Not valid utf8"))
            else:
                set_text(contents)
        if error_dialog is not None:
            error_dialog.connect("response", lambda w,resp: w.destroy())
            error_dialog.show()


    def do_open(self, action):
        dialog = gtk.FileChooserDialog("Select file",
                                       main_window,
                                       gtk.FILE_CHOOSER_ACTION_OPEN,
                                       (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,
                                        "_Copy File Directory", gtk.RESPONSE_OK))
        dialog.set_default_response(gtk.RESPONSE_OK)
        response = dialog.run()
        if response == gtk.RESPONSE_OK:
            open_filename = dialog.get_filename()
            load_file(open_filename)
        dialog.destroy()
        
def main():
    database_connect()
    gtk.main()

if __name__ == '__main__':
    main()
