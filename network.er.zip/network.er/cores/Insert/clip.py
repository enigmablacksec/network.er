#!/usr/bin/python

import os
import pygtk
pygtk.require('2.0')
import gobject
import gtk

class ClipArt(gtk.Dialog):
    def clip_art_import(dialog, parent = None):
	    gtk.Dialog.clip_art_import(dialog)
	    try:
	        dialog.set_screen(parent.get_screen())
	    except AttributeError:
	        dialog.connect('destroy', lambda *w: gtk.main_quit())
	    dialog.set_title("MEMBER REFERENCE WINDOW")
	    dialog.set_border_width(2)
	    dialog.set_default_size(750, 350)
	    vbox = gtk.VBox(False, 5)
	    dialog.add(vbox)
	    
       
	    
	    dialog.show_all()

def main():
    ClipArt()
    gtk.main()

if __name__ == '__main__':
    main()	    
	    
        
     
