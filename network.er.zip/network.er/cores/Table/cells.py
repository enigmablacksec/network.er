#!/usr/bin/env python

import os
import pygtk
pygtk.require('2.0')
import gobject
import gtk

#   columns
(
  COLUMN_NUMBER,
  COLUMN_PRODUCT,
  COLUMN_NAME,
  COLUMN_BALANCE,
  COLUMN_DATE,
  COLUMN_ID,
  COLUMN_REGISTERED,
  COLUMN_EDITABLE
) = range(8)

# data
articles = [
    [ 1, "Product Description", "Name of Member", 0, "Date Invited", "2016-00000", False, True ]
]

class EditableCells(gtk.Window):
    def __init__(self, parent=None):
        gtk.Window.__init__(self)
        try:
            self.set_screen(parent.get_screen())
        except AttributeError:
            self.connect('destroy', lambda *w: gtk.main_quit())
        self.set_title("MEMBER REFERENCE WINDOW")
        self.set_border_width(2)
        self.set_default_size(750, 400)
        #self.set_resizable(False)         

        vbox = gtk.VBox(False, 5)
        self.add(vbox)

        label = gtk.Label("Edit member reference and add them in database records. Remove or add new member with their profile.")
        vbox.pack_start(label, False, False)

        sw = gtk.ScrolledWindow()
        sw.set_shadow_type(gtk.SHADOW_ETCHED_IN)
        sw.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        vbox.pack_start(sw)

        # create model
        model = self.__create_model()

        # create tree view
        treeview = gtk.TreeView(model)
        treeview.set_rules_hint(True)
        treeview.get_selection().set_mode(gtk.SELECTION_SINGLE)

        self.__add_columns(treeview)

        sw.add(treeview)

        # some buttons
        hbox = gtk.HBox(True, 4)
        vbox.pack_start(hbox, False, False)

        button = gtk.Button(stock=gtk.STOCK_ADD)
        button.connect("clicked", self.on_add_item_clicked, model)
        hbox.pack_start(button)

        button = gtk.Button(stock=gtk.STOCK_REMOVE)
        button.connect("clicked", self.on_remove_item_clicked, treeview)
        hbox.pack_start(button)
        
        button = gtk.Button(stock=gtk.STOCK_PROPERTIES)
        button.connect('clicked', self.on_remove_item_clicked, treeview)
        vbox.pack_start(button, False, False, 0)              
        
        button = gtk.Button(stock=gtk.STOCK_SAVE)
        button.connect("clicked", self.on_remove_item_clicked, treeview)
        hbox.pack_start(button)

        self.show_all()
   
    def __create_model(self):

        # create list store
        model = gtk.ListStore(
            gobject.TYPE_INT,
            gobject.TYPE_STRING,
            gobject.TYPE_STRING,
            gobject.TYPE_STRING,
            gobject.TYPE_STRING,
            gobject.TYPE_STRING,
            gobject.TYPE_BOOLEAN,
            gobject.TYPE_BOOLEAN
       )

        # add items
        for item in articles:
            iter = model.append()

            model.set (iter,
                  COLUMN_NUMBER, item[COLUMN_NUMBER],
                  COLUMN_PRODUCT, item[COLUMN_PRODUCT],
                  COLUMN_NAME, item[COLUMN_NAME],
                  COLUMN_BALANCE, item[COLUMN_BALANCE],
                  COLUMN_DATE, item[COLUMN_DATE],
                  COLUMN_ID, item[COLUMN_ID],
                  COLUMN_REGISTERED, item[COLUMN_REGISTERED],
                  COLUMN_EDITABLE, item[COLUMN_EDITABLE]
           )
        return model


    def __add_columns(self, treeview):

        model = treeview.get_model()

        # number column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_NUMBER)

        column = gtk.TreeViewColumn("Number", renderer, text=COLUMN_NUMBER,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)

        # product column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_PRODUCT)

        column = gtk.TreeViewColumn("Product", renderer, 
        text=COLUMN_PRODUCT,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)
        
        # name column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_NAME)

        column = gtk.TreeViewColumn("Name", renderer, 
        text=COLUMN_NAME,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)
        
        # balance column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_BALANCE)

        column = gtk.TreeViewColumn("Balance", renderer, 
        text=COLUMN_BALANCE,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)        

        # date column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_DATE)

        column = gtk.TreeViewColumn("Date", renderer, 
        text=COLUMN_DATE,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)
        
        # id coluumn
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_ID)

        column = gtk.TreeViewColumn("Identification ", renderer, 
        text=COLUMN_ID,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)        
        
        # registered column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_REGISTERED)

        column = gtk.TreeViewColumn("Registration", renderer, 
        text=COLUMN_REGISTERED,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)        


    def on_add_item_clicked(self, button, model):

        new_item = [ 0, "Product Description", "Name of Member", 0, "Date Invited","2016-00000", False, True ]
        articles.append(new_item)

        iter = model.append()
        model.set (iter,
            COLUMN_NUMBER, new_item[COLUMN_NUMBER],
            COLUMN_PRODUCT, new_item[COLUMN_PRODUCT],
            COLUMN_NAME, new_item[COLUMN_NAME],
            COLUMN_BALANCE, new_item[COLUMN_BALANCE],
            COLUMN_DATE, new_item[COLUMN_DATE],
            COLUMN_ID, new_item[COLUMN_ID], 
            COLUMN_REGISTERED, new_item[COLUMN_REGISTERED],
            COLUMN_EDITABLE, new_item[COLUMN_EDITABLE]
       )


    def on_remove_item_clicked(self, button, treeview):

        selection = treeview.get_selection()
        model, iter = selection.get_selected()

        if iter:
            path = model.get_path(iter)[0]
            model.remove(iter)

            del articles[ path ]

    def on_cell_edited(self, cell, path_string, new_text, model):

        iter = model.get_iter_from_string(path_string)
        path = model.get_path(iter)[0]
        column = cell.get_data("column")

        if column == COLUMN_NUMBER:
            articles[path][COLUMN_NUMBER] = int(new_text)

            model.set(iter, column, articles[path][COLUMN_NUMBER])

        elif column == COLUMN_PRODUCT:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_PRODUCT] = new_text

            model.set(iter, column, articles[path][COLUMN_PRODUCT])
            
        elif column == COLUMN_NAME:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_NAME] = new_text

            model.set(iter, column, articles[path][COLUMN_NAME])
        
        elif column == COLUMN_BALANCE:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_BALANCE] = new_text

            model.set(iter, column, articles[path][COLUMN_BALANCE])
            
        elif column == COLUMN_DATE:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_DATE] = new_text

            model.set(iter, column, articles[path][COLUMN_DATE])

        elif column == COLUMN_ID:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_ID] = new_text

            model.set(iter, column, articles[path][COLUMN_ID])
            
        elif column == COLUMN_REGISTERED:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_REGISTERED] = new_text

            model.set(iter, column, articles[path][COLUMN_REGISTERED])                        
            
def main_cells():
    EditableCells()
    gtk.main()

if __name__ == '__main__':
    main_cells()
