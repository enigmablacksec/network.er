#!/usr/bin/python

import sys
import string
import re
import os
import urllib2

import pygtk
pygtk.require('2.0')
import gobject
import pango
import gtk

import tokenize
import keyword

import cores
#TABLE FOLDER
from cores.Table import cells
#CONNECT FOLDER
from cores.Connect import database_connect
D_TEMPL = '%sCores'

child_cores = {}
testgtk_cores = []
for descr, mod in cores.project_list:
    # Find some categorized cores
    try:
        main, child = descr.split('/')
    except ValueError:
        # No, only one application
        demo_class = D_TEMPL % re.sub('(\S+) *',
            lambda m:(m.group(1)[0].isupper() and m.group(1) or m.group(1).capitalize()),
            descr)
        testgtk_cores.append((descr, mod, demo_class))
    else:
        # Ok. Some more testing
        demo_class = D_TEMPL % re.sub('(\S+) *',
            lambda m:(m.group(1)[0].isupper() and m.group(1) or m.group(1).capitalize()),
            child)
        try:
            # Applicationgroup already defined?
            child_cores[main.upper()].append((child, mod, demo_class))
        except KeyError:
            # No. Start a new category
            child_cores.setdefault(main.upper(), []).append((child, mod, demo_class))
            testgtk_cores.append((main, None, None, child_cores[main.upper()]))

(
   TITLE_COLUMN,
   MODULE_COLUMN,
   FUNC_COLUMN,
   ITALIC_COLUMN
) = range(4)

CHILDREN_COLUMN = 3

class InputStream(object):
    ''' Simple Wrapper for File-like objects. [c]StringIO doesn't provide
        a readline function for use with generate_tokens.
        Using a iterator-like interface doesn't succeed, because the readline
        function isn't used in such a context. (see <python-lib>/tokenize.py)
    '''
    def __init__(self, data):
        self.__data = [ '%s\n' % x for x in data.splitlines() ]
        self.__lcount = 0
    def readline(self):
        try:
            line = self.__data[self.__lcount]
            self.__lcount += 1
        except IndexError:
            line = ''
            self.__lcount = 0
        return line


main_window = None
filename = None
page_setup = None
settings = None
file_changed = False
buffer = None
statusbar = None
vbox = None
active_prints = []

#   columns
(
  COLUMN_NUMBER,
  COLUMN_PRODUCT,
  COLUMN_NAME,
  COLUMN_BALANCE,
  COLUMN_DATE,
  COLUMN_ID,
  COLUMN_REGISTERED,
  COLUMN_EDITABLE
) = range(8)

# data
articles = [
    [ 1, "Product Description", "Name of Member", 0, "Date Invited", "2016-00000", False, True ]
]

def update_title():
    if filename is None:
        global basename
        basename = "Untitled.fil"
    else:
        basename = os.path.basename(filename)
    main_window.set_title("NetWorker GTK+ 0.1.1 - %s" % basename)

def update_statusbar():
    statusbar.pop(0)
  
    iter = buffer.get_iter_at_mark(buffer.get_insert())

    row = iter.get_line()
    col = iter.get_line_offset()

    print_str = "";
    if active_prints:
        op = active_prints[0]
        print_str = op.get_status_string()
  
    msg = "%d, %d%s %s" % (row, col, (file_changed and " - Modified" or ""),
                           print_str)

    statusbar.push(0, msg)

def update_ui():
    update_title()
    update_statusbar()

def get_text():
    start, end = buffer.get_bounds()
    return buffer.get_text(start, end, False)

def set_text(text):
    buffer.set_text(text)
    global file_changed
    file_changed = False
    update_ui()


def do_new(action):
    global filename
    filename = None
    set_text("")


def load_file(open_filename):
    error_dialog = None
    try:
        contents = file(open_filename).read()
    except IOError, ex:
        error_dialog = gtk.MessageDialog(main_window,
                                         gtk.DIALOG_DESTROY_WITH_PARENT,
                                         gtk.MESSAGE_ERROR,
                                         gtk.BUTTONS_CLOSE,
                                         "Error loading file %s:\n%s" %
                                         (open_filename,
                                          str(ex)))
    else:
        try:
            contents = contents.decode("utf-8")
        except UnicodeDecodeError:
            error_dialog = gtk.MessageDialog(main_window,
                                             gtk.DIALOG_DESTROY_WITH_PARENT,
                                             gtk.MESSAGE_ERROR,
                                             gtk.BUTTONS_CLOSE,
                                             "Error loading file %s:\n%s" %
                                             (open_filename,
                                              "Not valid utf8"))
        else:
            set_text(contents)
    if error_dialog is not None:
        error_dialog.connect("response", lambda w,resp: w.destroy())
        error_dialog.show()

#Modules
def do_open_cell(action):
     cells.main_cells()
def do_db_connect(action):
     database_connect.main()     
	
def do_open(action):
    dialog = gtk.FileChooserDialog("Select file",
                                   main_window,
                                   gtk.FILE_CHOOSER_ACTION_OPEN,
                                   (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,
                                    gtk.STOCK_OPEN, gtk.RESPONSE_OK))
    dialog.set_default_response(gtk.RESPONSE_OK)
    response = dialog.run()
    if response == gtk.RESPONSE_OK:
        open_filename = dialog.get_filename()
        load_file(open_filename)
    dialog.destroy()


def save_file(save_filename):
    global filename
    text = get_text()
    error_dialog = None

    try:
        file(save_filename, "w").write(text)
    except IOError, ex:
        error_dialog = gtk.MessageDialog(main_window,
                                         gtk.DIALOG_DESTROY_WITH_PARENT,
                                         gtk.MESSAGE_ERROR,
                                         gtk.BUTTONS_CLOSE,
                                         "Error saving to file %s:\n%s" %
                                         (open_filename,
                                          str(ex)))
        error_dialog.connect("response", lambda w,resp: w.destroy())
        error_dialog.show()
    else:
        if save_filename != filename:
            filename = save_filename
        file_changed = False
        update_ui()


def do_save_as(action):
    dialog = gtk.FileChooserDialog("Select file",
                                   main_window,
                                   gtk.FILE_CHOOSER_ACTION_SAVE,
                                   (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,
                                    gtk.STOCK_SAVE, gtk.RESPONSE_OK))
    dialog.set_default_response(gtk.RESPONSE_OK)
    response = dialog.run()

    if response == gtk.RESPONSE_OK:
        save_filename = dialog.get_filename()
        save_file(save_filename)
  
    dialog.destroy()

def do_save(action):
    if filename is None:
        do_save_as(action)
    else:
        save_file(filename)

class PrintData:
    text = None
    layout = None
    page_breaks = None


def begin_print(operation, context, print_data):
    width = context.get_width()
    height = context.get_height()
    print_data.layout = context.create_pango_layout()
    print_data.layout.set_font_description(pango.FontDescription("Sans 12"))
    print_data.layout.set_width(int(width*pango.SCALE))
    print_data.layout.set_text(print_data.text)

    num_lines = print_data.layout.get_line_count()

    page_breaks = []
    page_height = 0

    for line in xrange(num_lines):
      layout_line = print_data.layout.get_line(line)
      ink_rect, logical_rect = layout_line.get_extents()
      lx, ly, lwidth, lheight = logical_rect
      line_height = lheight / 1024.0
      if page_height + line_height > height:
	  page_breaks.append(line)
	  page_height = 0
      page_height += line_height

    operation.set_n_pages(len(page_breaks) + 1)
    print_data.page_breaks = page_breaks


def draw_page(operation, context, page_nr, print_data):
    assert isinstance(print_data.page_breaks, list)
    if page_nr == 0:
        start = 0
    else:
        start = print_data.page_breaks[page_nr - 1]

    try:
        end = print_data.page_breaks[page_nr]
    except IndexError:
        end = print_data.layout.get_line_count()
    
    cr = context.get_cairo_context()

    cr.set_source_rgb(0, 0, 0)
  
    i = 0
    start_pos = 0
    iter = print_data.layout.get_iter()
    while 1:
        if i >= start:
            line = iter.get_line()
            _, logical_rect = iter.get_line_extents()
            lx, ly, lwidth, lheight = logical_rect
            baseline = iter.get_baseline()
            if i == start:
                start_pos = ly / 1024.0;
            cr.move_to(lx / 1024.0, baseline / 1024.0 - start_pos)
            cr.show_layout_line(line)
        i += 1
        if not (i < end and iter.next_line()):
            break


def do_page_setup(action):
    global settings, page_setup
    if settings is None:
        settings = gtk.PrintSettings()
    page_setup = gtk.print_run_page_setup_dialog(main_window,
                                                 page_setup, settings)


def status_changed_cb(op):
    if op.is_finished():
        active_prints.remove(op)
    update_statusbar()


def do_print(action):
    global settings, page_setup
    print_data = PrintData()
    print_data.text = get_text()
    print_ = gtk.PrintOperation()
    if settings is not None:
        print_.set_print_settings(settings)

    if page_setup is not None:
        print_.set_default_page_setup(page_setup)
  
    print_.connect("begin_print", begin_print, print_data)
    print_.connect("draw_page", draw_page, print_data)

    try:
        res = print_.run(gtk.PRINT_OPERATION_ACTION_PRINT_DIALOG, main_window)
    except gobject.GError, ex:
        error_dialog = gtk.MessageDialog(main_window,
                                         gtk.DIALOG_DESTROY_WITH_PARENT,
                                         gtk._MESSAGE_ERROR,
                                         gtk.BUTTONS_CLOSE,
                                         ("Error printing file:\n%s" % str(ex)))
        error_dialog.connect("response", lambda w,resp: w.destroy())
        error_dialog.show()
    else:
        if res == gtk.PRINT_OPERATION_RESULT_APPLY:
            settings = print_.get_print_settings()

    if not print_.is_finished():
        active_prints.remove(print_)
        update_statusbar()
      
        print_.connect("status_changed", status_changed_cb)

def do_about(action):
        dialog = gtk.AboutDialog()
        dialog.set_name("NetWorker Project GTK+ v0.7.11\n")
        dialog.set_copyright("Copyright \302\251 2016 Free Security Team\nDeveloper: Isaac Arcilla <isaacdarcilla>")
        dialog.set_website("http://www.fsecurity.org")
        dialog.set_license(" Licensed under the GNU General Public License Version 2\n\n NetWorker is free software; You can redistribute it and/or modify it\n under the terms of the GNU General Public License\n as published by the Free Software Foundation; either version\n 2 of the License, or any later version.\n\n This program is distributed in the hope that it will be useful,\n but WITHOUT ANY WARRANTY; without even the implied warranty of \n MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n See the GNU General Public License for more details.\n\n You should have received a copy of the GNU General Public License\n along with this program.  If not, see http://www.gnu.org/licenses/")
       	## Close dialog on user response
        dialog.connect ("response", lambda d, r: d.destroy())
        dialog.show()
       
def do_about_app(action):
        dialog = gtk.AboutDialog()
        dialog.set_name("NetWorker Project\n")
        dialog.set_copyright("NetWorker Project is a free to use software developed by Free Security Team.\nhis software allows the user to manipulate data to a database, save new\nprofile and share them to others. This is useful in a business type company\nwhich aim member collaboration and support.")        
       	## Close dialog on user response
        dialog.connect ("response", lambda d, r: d.destroy())
        dialog.show()        

def do_check_update(action):
    try:
        latest_version = urllib2.urlopen("http://www.fsecurity.org/softwares/downloads.html").read().rstrip()
    except Exception,err:
        if type(err) == 'string':
            mes = err
        else:
            mess = err.message

def do_undo(action):
	if __name__=='__main__':
		gtk.main_quit()
	
def do_quit(action):
    if __name__ == '__main__':
        gtk.main_quit()

def do_quit_dialog(action):
        dialog = gtk.Dialog("Save changes to project \'"+basename+"\' before closing?", main_window, 0,
                ("_Save Project", gtk.RESPONSE_OK,
                "_Close Without Saving", gtk.RESPONSE_CANCEL, "_Cancel", gtk.RESPONSE_HELP)) 

                               
        label = gtk.Label("Save changes to project \'"+basename+"\' before closing? ")     
                                       
        main_window.show_all()
        dialog.set_resizable(False)                           
        dialog.set_default_response(gtk.RESPONSE_OK)
        response = dialog.run()

        if response == gtk.RESPONSE_OK:
            do_save_as(action)
        if response == gtk.RESPONSE_CANCEL:
            do_quit(action) 
        if response == gtk.RESPONSE_HELP:             
            create_window()
            
        main_window.show_all()            
   
        dialog.destroy()           
        

entries = [
   
   #EDIT MENU             
  ( "EditMenu", None, "_EDIT" ),
  ( "Undo", gtk.STOCK_UNDO,  "_Undo   ", "<control>Z" ),
  ( "Redo", gtk.STOCK_REDO, "_Redo   ","<control>Y" ),
  ( "Cut", gtk.STOCK_CUT, "_Cut   ","<control>X" ),
  ( "Copy", gtk.STOCK_COPY, "_Copy","<control>C" ),
  ( "Paste", gtk.STOCK_PASTE,"_Paste","<control>V" ),
  ( "Select All", gtk.STOCK_SELECT_ALL, "_Select All", "<control>A" ),
  ( "Sorting Options",gtk.STOCK_EXECUTE,"_Sorting Options" ),
  ( "Go To", gtk.STOCK_GO_FORWARD, 'Go To' ),
  ( "Find", gtk.STOCK_FIND,"Find" ),
  ( "Find and Replace", gtk.STOCK_FIND_AND_REPLACE, "Find and Replace" ),
  ( "Duplicate", None, "_Duplicate" ),
  ( "Rename", None, "_Rename" ),
  ( "Copy to", None, "_Copy to" ),
  ( "Move to", None, "_Move to" ),
  ( "Delete", gtk.STOCK_DELETE, "_Delete" ), 
  #INSERT MENU
  ( "InsertMenu", None, "_INSERT" ),
  ( "Clip Art", gtk.STOCK_DND, "_Clip Art","<alt><control>C" ),
  ( "Picture", gtk.STOCK_DND,"_Picture","<alt><control>P" ),
  ( "Text Box", gtk.STOCK_DND,"_Text Box","<alt><control>T" ),
  ( "Comment", gtk.STOCK_DND,"_Comment","<alt><control>F" ),
  ( "Shape", gtk.STOCK_DND,"_Shape","<alt><control>S" ),
  ( "Graphs", gtk.STOCK_DND, "_Graphs","<alt><control>G" ),
  #VIEW MENU
  ( "ViewMenu", None, "_VIEW" ),
  ( "Layout Settings", gtk.STOCK_EXECUTE, "_Layout Options", "<alt>L" ),
  ( "Web View", gtk.STOCK_EXECUTE, "_Web View Options", "<alt>B" ),
  ( "Show Options", gtk.STOCK_EXECUTE, "_Show Options", "<alt>S" ),
  ( "ZoomMenu", gtk.STOCK_ZOOM_IN, "Zoom" ),
  ( "Normal Size", gtk.STOCK_ZOOM_100,"_Normal Size" ),
  ( "Best Fit", gtk.STOCK_ZOOM_FIT,"_Best Fit" ),
  ( "Zoom In", gtk.STOCK_ZOOM_IN,"_Zoom In" ),
  ( "Zoom Out", gtk.STOCK_ZOOM_OUT,"_Zoom Out" ),
  #TABLE MENU
  ( "TableMenu", None, "_TABLE" ),
  ( "Columns", gtk.STOCK_EXECUTE,"_Columns", "<alt>C" ),
  ( "Rows", gtk.STOCK_EXECUTE,"Rows","<alt>R" ),
  ( "Profile", gtk.STOCK_EXECUTE,"Profile", "<shift>M" ),
  ( "Format", gtk.STOCK_PROPERTIES,"Format" ),
  ( "Table Properties", gtk.STOCK_PROPERTIES,"Table _Properties", None, None, do_open_cell  ),  
  #TOOLS MENU
  ( "ToolsMenu", None, "_TOOLS" ),
  ( "Spell Checker", gtk.STOCK_SPELL_CHECK,"Spell Checker", "<alt>1" ),
  ( "Dictionary", gtk.STOCK_SPELL_CHECK, "Dictionary", "<alt>3" ),
  ( "Plugins", gtk.STOCK_EXECUTE, "Plugins", "<alt>5" ),
  #SHARE MENU
  ( "ShareMenu", None, "_SHARE" ),
  ( "Share Project",gtk.STOCK_NETWORK, 'Share Profile via', "<shift><alt>P" ), 
  ( "Account", gtk.STOCK_EXECUTE, "Account Preference","<shift><alt>A"),
  ( "Mailing Options",  gtk.STOCK_EXECUTE,"Mailing Options"),
  #CONNECT MENU
  ( "ConnectMenu", None, "_CONNECT" ),
  ( "Database Connection",gtk.STOCK_NETWORK,"Database Connection", None, None, do_db_connect ),
  ( "Web Server Connection",gtk.STOCK_NETWORK,"Connect to Local Server" ),
  ( "Web Site Connection",gtk.STOCK_NETWORK,"Web Site Connection" ),
  ( "Network Configuration",gtk.STOCK_EXECUTE,"Network Configuration" ),
  #SETTINGS MENU
  ( "SettingsMenu", None, "_SETTINGS" ), 
  ( "Preferences", gtk.STOCK_EXECUTE,"Preferences","F12" ),
  ( "Costumize",gtk.STOCK_EXECUTE,"Costumize" ),
  ( "Themes",gtk.STOCK_EXECUTE,"Themes"),
  #HELP MENU
  ( "HelpMenu", None, "_HELP" ),
  ( "About", gtk.STOCK_ABOUT,                          
    "_About", "<shift><control>A",                    
    "About",                                  
    do_about ),
  ( "Help Content",gtk.STOCK_PROPERTIES, "Help Contents","F9" ), 
  ( "Search for Help",gtk.STOCK_HELP, "Search for Help", None ),
  ( "Updates",gtk.STOCK_DIALOG_WARNING,"Software Updates", None, None, do_check_update ),
  ( "About NetWorker",gtk.STOCK_ABOUT,"About NetWorker", None, None, do_about_app ),
  #IMPORT MENU
  ( "ImportMenu", gtk.STOCK_EXECUTE," _Import" ),
  ( "Graph", None, "Graph", "G" ),
  ( "Table", None, "Table", "T" ),  
  #FILE MENU
  ( "FileMenu", None, "_PROFILE" ),  
  ( "New", gtk.STOCK_NEW,                      # name, stock id
    "_New Profile", "<control>N",                      # label, accelerator
    "Create a new file",                       # tooltip
    do_new ),      
  ( "Open", gtk.STOCK_OPEN,                    # name, stock id
    "_Open","<control>O",                      # label, accelerator
    "Open a file",                             # tooltip
    do_open ), 
  ( "Save", gtk.STOCK_SAVE,                    # name, stock id
    "_Save","<control>S",                      # label, accelerator
    "Save current file",                       # tooltip
    do_save ),
  ( "SaveAs", gtk.STOCK_SAVE_AS,                  # name, stock id
    "Save _As", "<shift><control>S",                       # label, accelerator
    "Save to a file",                          # tooltip
    do_save_as ),
  ( "Quit", gtk.STOCK_QUIT,                    # name, stock id
    "_Quit", "<control>Q",                     # label, accelerator
    "Quit",                                    # tooltip
    do_quit_dialog ),
  ( "PageSetup", gtk.STOCK_PAGE_SETUP,                         # name, stock id
    "Page _Setup", None,                       # label, accelerator
    "Set up the page",                         # tooltip
    do_page_setup ),
  ( "Print", gtk.STOCK_PRINT,                  # name, stock id
     None, None,                               # label, accelerator
    "Print the document",                      # tooltip
    do_print ),
  ( "Close", gtk.STOCK_CLOSE,
  	 "_Close" ),
  ( "Sharing", "gtk-logo",
    "_Sharing", None,
    "Share your project" ),	 
]
   
ui_info ="""
<ui>
  <menubar name='MenuBar'>
<!--FILE MENU-->    
    <menu action='FileMenu'>
      <menuitem action='New'/>
      <menuitem action='Open'/>
      <separator/>
      <menuitem action='Save'/>
      <menuitem action='SaveAs'/>
      <separator/>
      <menuitem action='PageSetup'/>
      <menuitem action='Print'/>
      <separator/>
      <menu action='ImportMenu'>
        <menuitem action='Graph'/>
        <menuitem action='Table'/>
      </menu>
      <separator/>
      <menuitem action='Close'/>
      <menuitem action='Quit'/>
    </menu>
<!--EDIT MENU-->
    <menu action='EditMenu'>
      <menuitem action='Undo'/>
      <menuitem action='Redo'/>
      <separator/>
      <menuitem action='Cut'/>
      <menuitem action='Copy'/>
      <menuitem action='Paste'/>
      <separator/>
      <menuitem action='Select All'/>
      <menuitem action='Sorting Options'/>
      <menuitem action='Duplicate'/>
      <menuitem action='Rename'/>
      <separator/>
      <menuitem action='Go To'/>
      <menuitem action='Find'/>
      <menuitem action='Find and Replace'/>
      <separator/>
      <menuitem action='Copy to'/> 
      <menuitem action='Move to'/>
      <separator/>
      <menuitem action='Delete'/>
     </menu>
<!--INSERT MENU-->     
     <menu action='InsertMenu'>
       <menuitem action='Clip Art'/>
       <menuitem action='Picture'/>
       <separator/>
       <menuitem action='Comment'/>
       <menuitem action='Shape'/>
       <menuitem action='Graphs'/>
	</menu>
<!--VIEW MENU-->
	<menu action='ViewMenu'>
	   <menuitem action='Layout Settings'/>
	   <menuitem action='Web View'/>
	   <menuitem action='Show Options'/>
	   <separator/>
	   <menu action='ZoomMenu'>
	   	  <menuitem action='Normal Size'/>
	   	  <menuitem action='Best Fit'/>
	   	  <menuitem action='Zoom In'/>
	   	  <menuitem action='Zoom Out'/>
	   </menu>
	</menu> 
<!--TABLE MENU-->
	<menu action='TableMenu'>
	   <menuitem action='Columns'/>
	   <menuitem action='Rows'/>
	   <separator/>
	   <menuitem action='Profile'/>
	   <separator/>
	   <menuitem action='Format'/>
	   <menuitem action='Table Properties'/>
	 </menu>  
<!--TOOLS MENU-->
	 <menu action='ToolsMenu'>
	    <menuitem action='Spell Checker'/>
	    <menuitem action='Dictionary'/>
		<separator/>
		<menuitem action='Plugins'/>
	 </menu>	
<!--SHARE MENU-->
     <menu action='ShareMenu'>
        <menuitem action='Share Project'/>
        <separator/>
        <menuitem action='Account'/>
        <menuitem action='Mailing Options'/>
     </menu> 
<!--CONNECT MENU-->
	 <menu action='ConnectMenu'>   
	 	<menuitem action='Database Connection'/>
	 	<menuitem action='Web Server Connection'/>
	 	<menuitem action='Web Site Connection'/>
	 	<separator/>
	 	<menuitem action='Network Configuration'/>
	 </menu>   
<!--SETTINGS MENU-->
	 <menu action='SettingsMenu'>
	 	<menuitem action='Preferences'/>
	 	<menuitem action='Costumize'/>
	 	<separator/>
	 	<menuitem action='Themes'/>
	 </menu> 
<!--HELP MENU-->	    
    <menu action='HelpMenu'>
      <menuitem action='Search for Help'/>
      <menuitem action='Help Content'/>
      <separator/>
      <menuitem action='Updates'/>
      <separator/>
      <menuitem action='About NetWorker'/>
      <menuitem action='About'/>
    </menu>
  </menubar>
  <toolbar  name='ToolBar'>
    <toolitem action='New'/>
    <toolitem action='Open'/>
    <toolitem action='Save'/>
    <separator/>
    <toolitem action='Print'/>
    <toolitem action='PageSetup'/>
    <separator/>
    <toolitem action='Undo'/>
    <toolitem action='Redo'/>
    <toolitem action='Cut'/>
    <toolitem action='Copy'/>
    <toolitem action='Paste'/>
    <toolitem action='Select All'/>
    <separator/>
    <toolitem action='Find'/>
    <toolitem action='Find and Replace'/>
    <separator/>
    <toolitem action='Sharing'/>
    <separator expand='true'/>
  </toolbar>
</ui>
"""
def buffer_changed_callback(buffer):
    global file_changed
    file_changed = True
    update_statusbar()


def mark_set_callback(buffer, new_location, mark):
    update_statusbar()

def update_resize_grip(widget, event, statusbar):
    if event.changed_mask & (gtk.gdk.WINDOW_STATE_MAXIMIZED | 
                             gtk.gdk.WINDOW_STATE_FULLSCREEN):
        maximized = event.new_window_state & (gtk.gdk.WINDOW_STATE_MAXIMIZED | 
                                              gtk.gdk.WINDOW_STATE_FULLSCREEN)
        statusbar.set_has_resize_grip(not maximized)


def register_stock_icons():
    ''' This function registers our custom toolbar icons, so they
        can be themed.
    '''
    items = [('gtk-logo', '_GTK!', 0, 0, '')]
    # Register our stock items
    gtk.stock_add(items)

    # Add our custom icon factory to the list of defaults
    factory = gtk.IconFactory()
    factory.add_default()

    import os
    img_dir = os.path.join(os.path.dirname(__file__), 'images')
    img_path = os.path.join(img_dir, 'shared.svg')


def create_window():
    global main_window, statusbar, buffer, vbox
    main_window = gtk.Window()
    main_window.set_default_size(850, 450)
    if __name__ == '__main__':
        main_window.connect("delete-event", gtk.main_quit)
    actions = gtk.ActionGroup("Actions")
    actions.add_actions(entries)
    #main_window.set_resizable(False) 
  
    ui = gtk.UIManager()
    ui.insert_action_group(actions, 0)
    main_window.add_accel_group(ui.get_accel_group())
    main_window.set_border_width(0)

    ui.add_ui_from_string(ui_info)

    bar = ui.get_widget("/MenuBar")
    bar.show()
    
    table = gtk.Table(1, 4, False)
    main_window.add(table)
        
    table.attach(bar,
                 # X direction #          # Y direction
                 0, 1,                      0, 1,
                 gtk.EXPAND | gtk.FILL,     0,
                 0,                         0);

    bar = ui.get_widget("/ToolBar")
    bar.set_tooltips(True)
    bar.show()
    table.attach(bar,
            	 # X direction #       # Y direction
            	 0, 1,                   1, 2,
            	 gtk.EXPAND | gtk.FILL,  0,
            	 0,                      0)

    ## Create document 
    sw = gtk.ScrolledWindow()
    sw.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
    sw.set_shadow_type(gtk.SHADOW_IN)
    
    table.attach(sw,
		 # /* X direction */       /* Y direction */
                 0, 1,                   2, 3,
                 gtk.EXPAND | gtk.FILL,  gtk.EXPAND | gtk.FILL,
                 0,                      0)
  
    contents = gtk.TextView()
    contents.grab_focus()
    sw.add(contents)

    ## Create statusbar
  
    statusbar = gtk.Statusbar()
    table.attach(statusbar,
		 #/* X direction */       /* Y direction */
                 0, 1,                   3, 4,
                 gtk.EXPAND | gtk.FILL,  0,
                 0,                      0);
    
    ## Show text widget info in the statusbar */
    buffer = contents.get_buffer()
  
    buffer.connect_object("changed",
			  buffer_changed_callback,
                          None)
  
    buffer.connect_object("mark_set", # cursor moved
                          mark_set_callback,
                          None)
  
    main_window.connect_object("window_state_event", 
                               update_resize_grip,
                               statusbar,
                               0)
    """
    vbox = gtk.VBox(False, 0)
    main_window.add(vbox)

    vpaned = gtk.VPaned()
    vbox.pack_start(vpaned, True, True)
    vpaned.set_border_width(5)

    hpaned = gtk.HPaned()
    vpaned.add1(hpaned)

    frame = gtk.Frame()
    frame.set_shadow_type(gtk.SHADOW_IN)
    frame.set_size_request(200, 50)
    hpaned.add1(frame)
        
    frame = gtk.Frame()
    frame.set_shadow_type(gtk.SHADOW_IN)
    frame.set_size_request(60, 40)
    hpaned.add2(frame)

        ##CELLS
    main_window.set_border_width(4)

    label = gtk.Label("Edit member reference and add them in database records. Remove or add new member with their profile.")
    vbox.pack_start(label, False, False)

    sw = gtk.ScrolledWindow()
    sw.set_shadow_type(gtk.SHADOW_ETCHED_IN)
    sw.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
    vbox.pack_start(sw)

        # create model
    model = swl.__create_model()

        # create tree view
    treeview = gtk.TreeView(model)
    treeview.set_rules_hint(True)
    treeview.get_selection().set_mode(gtk.SELECTION_SINGLE)

    main_window.__add_columns(treeview)

    sw.add(treeview)

        # some buttons
    hbox = gtk.HBox(True, 4)
    vbox.pack_start(hbox, False, False)

    button = gtk.Button(stock=gtk.STOCK_ADD)
    button.connect("clicked", main_window.on_add_item_clicked, model)
    hbox.pack_start(button)

    button = gtk.Button(stock=gtk.STOCK_REMOVE)
    button.connect("clicked", main_window.on_remove_item_clicked, treeview)
    hbox.pack_start(button)
        
    button = gtk.Button(stock=gtk.STOCK_PROPERTIES)
    button.connect('clicked', main_window.on_remove_item_clicked, treeview)
    hbox.pack_start(button)              
        
    button = gtk.Button(stock=gtk.STOCK_SAVE)
    button.connect("clicked", main_window.on_remove_item_clicked, treeview)
    hbox.pack_start(button)   
    """  
    update_ui() 
    main_window.show_all()

def __create_model(self):

        # create list store
        model = gtk.ListStore(
            gobject.TYPE_INT,
            gobject.TYPE_STRING,
            gobject.TYPE_STRING,
            gobject.TYPE_STRING,
            gobject.TYPE_STRING,
            gobject.TYPE_STRING,
            gobject.TYPE_BOOLEAN,
            gobject.TYPE_BOOLEAN
       )

        # add items
        for item in articles:
            iter = model.append()

            model.set (iter,
                  COLUMN_NUMBER, item[COLUMN_NUMBER],
                  COLUMN_PRODUCT, item[COLUMN_PRODUCT],
                  COLUMN_NAME, item[COLUMN_NAME],
                  COLUMN_BALANCE, item[COLUMN_BALANCE],
                  COLUMN_DATE, item[COLUMN_DATE],
                  COLUMN_ID, item[COLUMN_ID],
                  COLUMN_REGISTERED, item[COLUMN_REGISTERED],
                  COLUMN_EDITABLE, item[COLUMN_EDITABLE]
           )
        return model


def __add_columns(self, treeview):

        model = treeview.get_model()

        # number column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_NUMBER)

        column = gtk.TreeViewColumn("Number", renderer, text=COLUMN_NUMBER,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)

        # product column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_PRODUCT)

        column = gtk.TreeViewColumn("Product", renderer, 
        text=COLUMN_PRODUCT,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)
        
        # name column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_NAME)

        column = gtk.TreeViewColumn("Name", renderer, 
        text=COLUMN_NAME,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)
        
        # balance column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_BALANCE)

        column = gtk.TreeViewColumn("Balance", renderer, 
        text=COLUMN_BALANCE,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)        

        # date column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_DATE)

        column = gtk.TreeViewColumn("Date", renderer, 
        text=COLUMN_DATE,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)
        
        # id coluumn
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_ID)

        column = gtk.TreeViewColumn("Identification ", renderer, 
        text=COLUMN_ID,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)        
        
        # registered column
        renderer = gtk.CellRendererText()
        renderer.connect("edited", self.on_cell_edited, model)
        renderer.set_data("column", COLUMN_REGISTERED)

        column = gtk.TreeViewColumn("Registration", renderer, 
        text=COLUMN_REGISTERED,
                               editable=COLUMN_EDITABLE)
        treeview.append_column(column)        

def on_add_item_clicked(self, button, model):
        new_item = [ 0, "Product Description", "Name of Member", 0, "Date Invited","2016-00000", False, True ]
        articles.append(new_item)

        iter = model.append()
        model.set (iter,
            COLUMN_NUMBER, new_item[COLUMN_NUMBER],
            COLUMN_PRODUCT, new_item[COLUMN_PRODUCT],
            COLUMN_NAME, new_item[COLUMN_NAME],
            COLUMN_BALANCE, new_item[COLUMN_BALANCE],
            COLUMN_DATE, new_item[COLUMN_DATE],
            COLUMN_ID, new_item[COLUMN_ID], 
            COLUMN_REGISTERED, new_item[COLUMN_REGISTERED],
            COLUMN_EDITABLE, new_item[COLUMN_EDITABLE]
       )


def on_remove_item_clicked(self, button, treeview):

        selection = treeview.get_selection()
        model, iter = selection.get_selected()

        if iter:
            path = model.get_path(iter)[0]
            model.remove(iter)

            del articles[ path ]

def on_cell_edited(self, cell, path_string, new_text, model):

        iter = model.get_iter_from_string(path_string)
        path = model.get_path(iter)[0]
        column = cell.get_data("column")

        if column == COLUMN_NUMBER:
            articles[path][COLUMN_NUMBER] = int(new_text)

            model.set(iter, column, articles[path][COLUMN_NUMBER])

        elif column == COLUMN_PRODUCT:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_PRODUCT] = new_text

            model.set(iter, column, articles[path][COLUMN_PRODUCT])
            
        elif column == COLUMN_NAME:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_NAME] = new_text

            model.set(iter, column, articles[path][COLUMN_NAME])
        
        elif column == COLUMN_BALANCE:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_BALANCE] = new_text

            model.set(iter, column, articles[path][COLUMN_BALANCE])
            
        elif column == COLUMN_DATE:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_DATE] = new_text

            model.set(iter, column, articles[path][COLUMN_DATE])

        elif column == COLUMN_ID:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_ID] = new_text

            model.set(iter, column, articles[path][COLUMN_ID])
            
        elif column == COLUMN_REGISTERED:
            old_text = model.get_value(iter, column)
            articles[path][COLUMN_REGISTERED] = new_text

            model.set(iter, column, articles[path][COLUMN_REGISTERED])                        
 
		##END
        ## Now create toggle buttons to control sizing


def main(argv):
    create_window()

    try:
        fname = argv[1]
    except IndexError:
        pass
    else:
        load_file(fname)
  
    gtk.main()

def NetWorker(win):
    create_window()
    main_window.set_transient_for(win)
    return main_window

if __name__ == '__main__':
    sys.exit(main(sys.argv))
    NetWorker(win)
